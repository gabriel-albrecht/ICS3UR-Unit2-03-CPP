// Copyright (c) 2019 St. Mother Teresa HS All rights reserved.
//
// Created by Gabriel A
// Created on Nov 2019
// This program calculates the circumference of a circle with user input

#include <iostream>

int main() {
    // this function calculates circumference of a circle
    const double tpi = 6.28318530718;
    int radius;
    double circumference;

    // input
    std::cout << "Enter radius of the circle (km): ";
    std::cin >> radius;

    // process
    circumference = tpi*radius;

    // output
    std::cout << "" << std::endl;
    std::cout << "Circumference is " << circumference << " km" << std::endl;
}
